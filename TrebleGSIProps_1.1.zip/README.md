## Treble GSI Props

Automatically set properties to vendor ones for some Treble GSI ROMs. Based on sensitive_props by HuskyDG and some parts from phh copyprop in rw-system.sh

I'm here to introduce you the greatest thief [@XNEOFF](https://github.com/XNEOFF) !
So, what did he do?

* He stole this module with absolute zero modifications to the main code, just replaced my name with his and removed the credits to phh and HuskyDG on the description(where most of the code came from)
* He probably also stole other modules and flashable zips


## Credits
These people have helped this project in some way or another, so they should be the ones who receive all the credit:
- [phhusson](https://github.com/phhusson)
- [HuskyDG](https://github.com/HuskyDG)
