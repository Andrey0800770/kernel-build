#!/sbin/sh
ui_print() { echo -e "ui_print $1\nui_print" >> "/tmp/files/outfd"; }

ui_print "Android 15 GSI Fix"
ui_print "For Samsung Galaxy S9+/S9/N9"
ui_print "By Andrey0800770"
ui_print "\n"
ui_print "\n"

mount /vendor

arquivo="/vendor/etc/vintf/manifest.xml"

ui_print "Patching Manifest.xml..."
ui_print "\n"
awk '
BEGIN { found=0 }
/<hal format="hidl">/ { if (found == 0) { block_start=NR } }
/<name>android.hardware.configstore<\/name>/ { if (found == 0) { found=1 } }
/<\/hal>/ { if (found == 1) { found=0; for (i=block_start; i<=NR; i++) delete lines[i]; next } }
{ lines[NR]=$0 }
END { for (i=1; i<=NR; i++) if (lines[i] != "") print lines[i] }
' "$arquivo" > temp && mv temp "$arquivo"
ui_print "\n"
ui_print "Done!"

umount /vendor